#include<iostream>

using namespace std;

int main() 
{	
	float coins, result =0;

	cout << "How much coins: ";
	cin >> coins;

	for (int i = 0; i < coins; i++)
	{
		float coin;

		cout << "Coin type: ";
		cin >> coin;

		cout << endl;

		result += coin;
	}

	cout << "You have total of:" << result<< " money";
}