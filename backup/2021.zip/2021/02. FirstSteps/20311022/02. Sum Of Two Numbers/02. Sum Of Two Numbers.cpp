
#include<iostream>

using namespace std;

int SumTwoNums(int firstNumber, int secondNumber)
{
	return firstNumber + secondNumber;
}

int main()
{
	int firstNumber, secondNumber;

	cout << "First number:";
	cin >> firstNumber;

	cout << endl;

	cout << "Second number:";
	cin >> secondNumber;

	cout << endl;

	int result = SumTwoNums(firstNumber, secondNumber);

	cout << "Result: " << result << endl;
}