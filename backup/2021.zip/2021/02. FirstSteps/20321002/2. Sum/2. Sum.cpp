﻿//02. Сума на две цели числа
#include<iostream>
using namespace std;
int main()
{
    int a, b, c;
    cout << "a=";
    cin >> a;
    cout << "b=";
    cin >> b;
    c = a + b;
    cout << "sum=" << c << endl;

    return 0;
}