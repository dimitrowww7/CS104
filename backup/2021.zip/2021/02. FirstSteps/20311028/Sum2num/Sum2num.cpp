﻿// Сума на две числа
#include<iostream>
using namespace std;

int main()
{
	int a = 3, b = 5;

	int c = a + b;

		cout << "sum=" << c << endl;

	return 0;

}
