// Hello World.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include<iostream>
using namespace std;
int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

