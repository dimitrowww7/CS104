﻿// 02. Сума на две цели числа

#include <iostream>
using namespace std;
int main()
{
    // Създаване на променливите
    int a, b, c;

    // Въвеждане на стойност за a и b
    cout << "a = ?, b = ?" << endl;
    cin >> a >> b;

    // Събиране на a и b
    c = a + b;

    // Отпечатване на резултата
    cout << "Sum = " << c << endl;

    return 0;
}