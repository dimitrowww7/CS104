﻿#include <iostream>

int main()
{
    int a, b, c;

    std::cout << "a=";
    std::cin >> a;

    std::cout << "b=";
    std::cin >> b;

    c = a + b;

    std::cout << "Sum=" << c << std::endl;
}