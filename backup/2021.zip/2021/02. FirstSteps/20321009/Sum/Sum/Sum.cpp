﻿// Сума на две цели числа 

#include <iostream>
using namespace std;
int main()
{
	// Променливи 
	int a, b, c;
	

	//Стойност за a
	cout << "a=";
	cin >> a; 

	//Стойност за b
	cout << "b=";
	cin >> b;

	//Събиране 
	c = a + b;

	//Резултат 
	cout << "a + b =" << c << endl; 
	
	return 0;
}
