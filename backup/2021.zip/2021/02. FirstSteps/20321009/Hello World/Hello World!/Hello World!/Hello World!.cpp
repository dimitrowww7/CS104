// Hello World!, Bye World!

#include <iostream>
using namespace std;
int main()
{
   cout << "Hello World!" << endl;
   cout << "Bye World!\n";
   return 0; 
}


