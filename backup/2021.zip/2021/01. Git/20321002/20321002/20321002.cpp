#include <iostream>
using namespace std;
int main()
{
	while (true)
	{
		cout << "10011 101 110 ";
	}
	return 0;
}
