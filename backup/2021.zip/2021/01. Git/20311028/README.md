# Задача 1. Клониране на хранилището
1. Стартирайте Microsoft Visual Comunity 2019
2. Натиснете: Clone Repository
3. Поставете следния линк:
```
https://github.com/dimitarminchev/CS104
```
4. Натсинете: Clone

# Задача 2. Създаване на първи проект на C++
1. Стартирайте Microsoft Visual Comunity 2019
2. File > New > Project
3. Изберете: C++ > Windows > Console > Console App
4. Project name: **FAKNO**
5. Location: **C:\\Users\\mitko\\Desktop\\CS104\\1. Git\\**
6. Сорс кода на програмата:
```
#include <iostream>
using namespace std;
int main()
{
    cout << "Hello World!" << endl;
}
```
7. Git > Push

