//#include<iostream>
//
//using namespace std;
//
//int PCalc(int a, int b)
//{
//	int p = 2 * (a + b);
//	
//
//	return p;
//}
//
//int SClac(int a, int b)
//{
//	int s = a * b;
//
//	return s;
//}
//
//int main()
//{
//	int a, b, p, s;
//
//	cout << "a: ";
//	cin >> a;
//
//	cout << "b: ";
//	cin >> b;
//
//	p = PCalc(a, b);
//	s = SClac(a, b);
//
//	cout << "p= " << p;
//
//	cout << endl;
//
//	cout << "s= " << s;
//}
//
