//#define _USE_MATH_DEFINES
//
//#include<iostream>
//#include <cmath>
//
//using namespace std;
//
//float PCalc(float r)
//{
//	float p = 2 * M_PI * r;
//
//	return p;
//}
//
//float SClacl(float r)
//{
//	float s = M_PI * r * r;
//
//	return s;
//}
//
//int main() 
//{
//	float r, p, s;
//
//	cout << "Radius: ";
//	cin >> r;
//
//	cout << endl;
//
//	p = PCalc(r);
//	s = SClacl(r);
//
//	cout << "p= " << p << endl;
//	cout << "s= " << s << endl;
//
//}