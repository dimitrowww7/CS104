﻿#include <iostream>
using namespace std;
int main()

{

    int a, b;
    cout << "Please enter a number for a = ";
    cin >> a;
    cout << "Please enter a number for b = ";
    cin >> b;
    int c = a + b;
    cout << "a + b = " << c << endl;
    return 0;

}