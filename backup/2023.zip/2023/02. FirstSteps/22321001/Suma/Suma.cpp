#include <iostream>
using namespace std;
int main()
{
    int a;
    a = 2;
    int b;
    b = 3;
    int c;
    c = a + b;
    cout << "c=" << c << endl;
    return 0;
}

