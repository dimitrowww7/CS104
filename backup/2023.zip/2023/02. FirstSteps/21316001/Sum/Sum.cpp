#include <iostream>
using namespace std;
int main()
{
    int a = 84;
    int b = 122;

    cout << "a+b=" << a+b << endl;

    return 0;
}