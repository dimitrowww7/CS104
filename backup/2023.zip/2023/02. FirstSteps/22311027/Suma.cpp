#include<iostream>

using namespace std;

int main()
{
    int a,b;

    cout << "a=";
    cin >> a;

    cout << "b=";
    cin >> b;

    int c = a + b;

    cout << "a+b=" << c << endl;

    return 0;
}
