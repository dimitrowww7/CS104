#include<iostream>
using namespace std;

int main() {
    int a, b, c;
    cout << "Въведете стойности за 'a' и 'b'" << endl;
    cin >> a >> b;
    c = a + b;

    cout << "sum = " << c << endl;
    return 0;
}