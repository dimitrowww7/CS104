# Git
**Сорс-контрол**. Системи за управление на версиите и екипно взаимодействие.

## 1. Клониране на хранилището
1. Стартирайте интегрираната среда за разработка: **Microsoft Visual Comunity 2022**
2. Изберете: **Clone Repository**
3. Използвайте следния Интернет адрес:
```
https://github.com/dimitarminchev/CS104
```
4. Натиснете: Clone

## 2. Създаване на първи проект на C++
1. Стартирайте интегрираната среда за разработка: **Microsoft Visual Comunity 2022**
2. Изпълнете: **File > New > Project**
3. Изберете последователността: **C++ > Windows > Console > Console App**
4. Име на проекта (Project name): **FAKNO**
5. Мeстоположение (Location): **C:\\Users\\mitko\\Desktop\\CS104\\1. Git\\**
6. Поставете следния програмен код:
```
#include <iostream>
using namespace std;
int main()
{
    cout << "Hello World!" << endl;
}
```
7. Публикувайте в хранилището промените: **Git > Push**
