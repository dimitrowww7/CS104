
#include <iostream>
using namespace std; 
int main()
{

	cout << "hello" ;

 return 0;

}

