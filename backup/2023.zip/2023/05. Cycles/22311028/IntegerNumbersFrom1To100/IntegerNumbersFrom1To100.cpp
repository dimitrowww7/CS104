﻿﻿#include <iostream>
using namespace std;
int main()
{
    // Отпечатване на числата от 1 до 100
    int k;

    for (k = 1; k <= 100; k++)
    {
        cout << k << " ";
    }

    return 0;
}