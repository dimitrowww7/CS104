#include <iostream>
using namespace std;
int main()
{
 
    int k;

    for (k = 1; k <= 100; k++)
    {
        cout << k << " ";
    }

    return 0;
}
