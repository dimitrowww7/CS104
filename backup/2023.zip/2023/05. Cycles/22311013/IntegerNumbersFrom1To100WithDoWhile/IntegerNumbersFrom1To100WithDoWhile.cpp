#include <iostream>
using namespace std;
int main()
{
    int k = 1;

    do
    {
        cout << k << " ";
        k = k + 1;
    } while (k <= 100);

    cout << endl;
    return 0;
}