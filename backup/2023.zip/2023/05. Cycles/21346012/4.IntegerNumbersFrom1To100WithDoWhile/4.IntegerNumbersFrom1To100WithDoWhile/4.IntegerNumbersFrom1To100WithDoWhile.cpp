#include <iostream>
using namespace std;
int main()
{
    // Отпечатване на числата от 1 до 100
    int k = 1;

    do
    {
        cout << k << " ";
        k = k + 1;
    } while (k <= 100);

    return 0;
}