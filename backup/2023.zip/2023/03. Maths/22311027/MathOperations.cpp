#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout << "a=";
    cin >> a;

    cout << "b=";
    cin >> b;

    cout << (a + b) << endl;
    cout << (a - b) << endl;
    cout << (a * b) << endl;
    cout << (a / b) << endl;
    cout << (a % b) << endl;

    return 0;
}