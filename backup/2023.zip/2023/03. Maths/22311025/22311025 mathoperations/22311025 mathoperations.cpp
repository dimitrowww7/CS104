﻿#include <iostream>
using namespace std;
int main()
{
    int a, b;

    cout << "a=";
    cin >> a;

    cout << "b=";
    cin >> b;

    // Операции
    cout << (a + b) << endl;
    cout << (a - b) << endl;
    cout << (a * b) << endl;
    cout << (a / b) << endl;
    cout << (a % b) << endl;

    return 0;
}
